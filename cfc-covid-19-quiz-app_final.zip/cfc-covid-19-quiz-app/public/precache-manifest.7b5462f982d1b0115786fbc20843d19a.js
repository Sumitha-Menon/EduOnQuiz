self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "12e09f022a8e05bb5e54b9febe92c765",
    "url": "/index.html"
  },
  {
    "revision": "f05cf5a8d80d257d363c",
    "url": "/static/css/main.fc1dc1dd.chunk.css"
  },
  {
    "revision": "0380da9baba932624d8d",
    "url": "/static/js/2.b8329bd4.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.b8329bd4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f05cf5a8d80d257d363c",
    "url": "/static/js/main.8b8e0661.chunk.js"
  },
  {
    "revision": "3bb02338304888f7e826",
    "url": "/static/js/runtime-main.cee7b8e8.js"
  },
  {
    "revision": "ee7cd8ed2dcec943251eb2763684fc6f",
    "url": "/static/media/logo.ee7cd8ed.svg"
  }
]);