self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4da623ee5eb3d3ddab6c6c7168e70872",
    "url": "/index.html"
  },
  {
    "revision": "fda33109903b2d5b6783",
    "url": "/static/css/main.49878f47.chunk.css"
  },
  {
    "revision": "0380da9baba932624d8d",
    "url": "/static/js/2.b8329bd4.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.b8329bd4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fda33109903b2d5b6783",
    "url": "/static/js/main.8b8e0661.chunk.js"
  },
  {
    "revision": "3bb02338304888f7e826",
    "url": "/static/js/runtime-main.cee7b8e8.js"
  },
  {
    "revision": "ee7cd8ed2dcec943251eb2763684fc6f",
    "url": "/static/media/logo.ee7cd8ed.svg"
  }
]);