self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "95db56208a60514badac68cce7e149b3",
    "url": "/index.html"
  },
  {
    "revision": "eb940add859660b865a7",
    "url": "/static/css/main.7b254413.chunk.css"
  },
  {
    "revision": "c381c9b2e548002e8e5d",
    "url": "/static/js/2.104fae8e.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.104fae8e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "eb940add859660b865a7",
    "url": "/static/js/main.8c9ff337.chunk.js"
  },
  {
    "revision": "3bb02338304888f7e826",
    "url": "/static/js/runtime-main.cee7b8e8.js"
  },
  {
    "revision": "ee7cd8ed2dcec943251eb2763684fc6f",
    "url": "/static/media/logo.ee7cd8ed.svg"
  }
]);