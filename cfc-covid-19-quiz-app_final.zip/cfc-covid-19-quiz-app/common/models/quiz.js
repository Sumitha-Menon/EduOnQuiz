'use strict';

module.exports = function(Quiz) {

};
