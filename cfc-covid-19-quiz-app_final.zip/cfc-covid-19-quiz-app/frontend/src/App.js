import React, { useState, useEffect, useCallback } from "react";
import logo from "./logo.svg";
import "./App.css";

async function fetchQuiz(id) {
  const resp = await fetch(
    `/api/quizes/${id}/questions`
  );
  const data = await resp.json();
  return data;
}

/*Function to call the users login api and authenticate
We should call the method POST and headers as application/json
to get the correct response back from api */
async function login(bodydata={}) {
  const resp = await fetch(
    `/api/Users/login`,
    {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body:JSON.stringify(bodydata)
    }
  );
  const data = await resp.json();
  return data;
}

function App() {
  const [quiz, setQuiz] = useState([]);
  const [selectedAnswers, setSelectedAnswers] = useState({});

  /*Below are the state variables used for authentication purposes*/
  /**********************************************/
  const [authStatus,setAuthStatus]=useState({});
  const [loginDisplay,setLoginDisplay]=useState({});
  const [username,setUsername]=useState({});
  const [password,setPassword]=useState({});
  const [quizid,setQuizID]=useState({});
  /**********************************************/
  
  
  useEffect(() => {
    //const id = 3;
    //By default the authentication status will be not authenticated
    setAuthStatus("notauthenticated");
    //Fetch the default quiz
    //fetchQuiz(id).then(setQuiz);
  }, []);
  const handleAnswerSelected = useCallback(
    (ev) => {
      console.log(ev);
      const { name, value } = ev.target;
      setSelectedAnswers((oldData) => ({ ...oldData, [name]: Number(value)}));
    },
    [setSelectedAnswers]
  );
  const handleCheckAnswers = useCallback(
    (ev) => {
      console.log(quiz, selectedAnswers)
      const allCorrect = quiz.every((question) => question.correct_answer_index === selectedAnswers[question.id])
      alert(allCorrect ? 'You win!' : 'Something is incorrect')
    },
    [quiz, selectedAnswers]
  );

  /*The login handler is called when user submits the login credentials */
  const loginHandler=()=>{    
    const data={"username":username,"password":password};
    login(data).then(data => {
      //if the data returned from api is valid
      //Validate the quiz id entered using the quiz api and based on the response
      //authenticate and move to the quiz screen
      if(!data.error){   
        //Call the fetch quiz api with the entered quiz id 
        //and retrieve the response    
        fetchQuiz(quizid).then(data => {
          if(!data.error){
            //once we receive the proper response without error
            //set the received quiz data on the quiz state 
            //and set auth status and hide the login display
           setQuiz(data); 
           setAuthStatus("authenticated");
           setLoginDisplay("hide");  
          }else{
            alert("Invalid Quiz ID")
          }          
        }).catch((error) => {
          alert("login failed, please check your credentials and quiz id")
        });   
      }else{
        alert("login failed, please check your credentials")
      }      
    }).catch((error) => {
      alert("login failed, please check your credentials")
    });

  }  
  return (
    <div className="App">
      <header className="App-header">
        <img alt="IBM Logo" src="ibm-logo-white.png" class="logo"/>
        <h1>Covid Awareness Quiz</h1>

        <div class={loginDisplay}>

        <input type="text" id="username" placeholder="Username" onChange={e => setUsername(e.target.value)}></input><br/><br/>
        <input type="password" id="password" placeholder="Password" onChange={e => setPassword(e.target.value)}></input> <br/><br/>
        <input type="text" id="quizid" placeholder="Class" onChange={e => setQuizID(e.target.value)}></input> <br/><br/>

        <button class="loginButton" onClick={loginHandler}>Sign In</button>

        </div>

        <div class={authStatus}>
        <ul>
          {quiz.map((question) => (
            <div key={question.id}>
              <h2>{question.question_text}</h2>
              {question.answers.map((answer, idx) => (
                <div key={idx}>
                  <label>
                    <input
                      checked={ idx === selectedAnswers[question.id]} 
                      onChange={handleAnswerSelected}
                      type="radio"
                      value={idx}
                      name={question.id}
                    />
                    {answer}
                  </label>
                </div>
              ))}
            </div>
          ))}
        </ul>
        <button class="submitButton"  onClick={handleCheckAnswers}>Submit</button>
        </div>
      {/* <p>Go Further with <a href="https://reactjs.org/tutorial/tutorial.html">React</a> and <a href="https://loopback.io/">Loopback</a></p>
      <p>Deploy your app using <a href="https://github.com/IBM/nodejs-express-app#ibm-cloud-developer-tools">Cloud Foundry</a> or <a href="https://developer.ibm.com/patterns/app-modernization-s2i-openshift/">Kubernetes and OpenShift</a>.</p> */}
      </header>
    </div>
  );
}

export default App;
