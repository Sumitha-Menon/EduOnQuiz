self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "10bd5d213c00ffd4abea43e32d6e2e8b",
    "url": "/index.html"
  },
  {
    "revision": "dcf2747403c62b27844b",
    "url": "/static/css/main.3c3b778d.chunk.css"
  },
  {
    "revision": "0380da9baba932624d8d",
    "url": "/static/js/2.b8329bd4.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.b8329bd4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "dcf2747403c62b27844b",
    "url": "/static/js/main.0ae055a7.chunk.js"
  },
  {
    "revision": "3bb02338304888f7e826",
    "url": "/static/js/runtime-main.cee7b8e8.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);